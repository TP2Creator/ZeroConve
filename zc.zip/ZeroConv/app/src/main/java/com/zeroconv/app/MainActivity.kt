package com.zeroconv.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.*
import kotlinx.coroutines.*
import java.io.File
import java.io.OutputStream

private val BG = Color(0xFF0D0E1A)
private val CARD = Color(0xFF171930)
private val MUTED = Color(0xFF9A9DC0)
private val A = Color(0xFF6C5CE7)
private val B = Color(0xFF00C2FF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ZeroConvApp() }
    }
}

@Composable
fun ZeroConvApp() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) }
    var uri by remember { mutableStateOf<Uri?>(null) }
    var name by remember { mutableStateOf("") }
    var fmt by remember { mutableStateOf("PNG") }
    var quality by remember { mutableFloatStateOf(90f) }
    var status by remember { mutableStateOf("") }
    var progress by remember { mutableFloatStateOf(0f) }
    var busy by remember { mutableStateOf(false) }

    val tabs = listOf("🖼 Image", "🎵 Audio", "🎬 Video")
    val formats = listOf(listOf("PNG", "JPG", "WEBP"), listOf("M4A"), listOf("MP4", "M4A"))
    val mimes = listOf("image/*", "audio/*", "video/*")

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) { uri = u; name = displayName(ctx, u); status = ""; progress = 0f }
    }

    fun selectTab(i: Int) {
        if (busy) return
        tab = i; fmt = formats[i][0]; uri = null; name = ""; status = ""; progress = 0f
    }

    fun start() {
        val u = uri ?: return
        busy = true; progress = 0f; status = "Converting…"
        val base = name.substringBeforeLast('.').ifBlank { "zeroconv" }
        if (tab == 0) {
            scope.launch {
                val r = withContext(Dispatchers.IO) { runCatching { convertImage(ctx, u, base, fmt, quality.toInt()) } }
                status = r.fold({ "✓ Saved to Downloads/ZeroConv\n$it" }, { "⚠ ${it.message}" })
                progress = 1f; busy = false
            }
        } else {
            val ext = if (fmt == "MP4") "mp4" else "m4a"
            val mime = if (fmt == "MP4") "video/mp4" else "audio/mp4"
            val tmp = File(ctx.cacheDir, "zc_out.$ext").also { it.delete() }
            val item = EditedMediaItem.Builder(MediaItem.fromUri(u))
                .setRemoveVideo(ext == "m4a").build()
            val t = Transformer.Builder(ctx)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                        scope.launch {
                            val r = withContext(Dispatchers.IO) {
                                runCatching { saveToDownloads(ctx, "$base.$ext", mime) { o -> tmp.inputStream().use { it.copyTo(o) } } }
                            }
                            status = r.fold({ "✓ Saved to Downloads/ZeroConv\n$it" }, { "⚠ ${it.message}" })
                            progress = 1f; busy = false
                        }
                    }
                    override fun onError(composition: androidx.media3.transformer.Composition, exportResult: ExportResult, exportException: ExportException) {
                        status = "⚠ ${exportException.message}"; busy = false
                    }
                }).build()
            t.start(item, tmp.absolutePath)
            scope.launch {
                val h = ProgressHolder()
                while (busy) {
                    if (t.getProgress(h) != Transformer.PROGRESS_STATE_NOT_STARTED) progress = h.progress / 100f
                    delay(300)
                }
            }
        }
    }

    Column(
        Modifier.fillMaxSize().background(BG).statusBarsPadding().navigationBarsPadding()
            .verticalScroll(rememberScrollState()).padding(18.dp)
    ) {
        Text("ZeroConv", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
        Text("Convert images, audio & video on your device", color = MUTED, fontSize = 14.sp)
        Spacer(Modifier.height(16.dp))

        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(CARD).padding(5.dp)) {
            tabs.forEachIndexed { i, t ->
                Box(
                    Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                        .background(if (i == tab) Brush.horizontalGradient(listOf(A, B)) else Brush.horizontalGradient(listOf(CARD, CARD)))
                        .clickable { selectTab(i) }.padding(vertical = 12.dp),
                    contentAlignment = Alignment.Center
                ) { Text(t, color = if (i == tab) Color.White else MUTED, fontWeight = FontWeight.SemiBold, fontSize = 14.sp) }
            }
        }

        Spacer(Modifier.height(14.dp))
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CARD).padding(16.dp)) {
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF1F2242))
                    .clickable(enabled = !busy) { picker.launch(mimes[tab]) }.padding(vertical = 28.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (uri == null) "＋" else "📄", fontSize = 32.sp, color = Color.White)
                    Text(if (uri == null) "Choose a file" else name, color = Color.White, fontWeight = FontWeight.SemiBold)
                    if (uri == null) Text("Tap to browse", color = MUTED, fontSize = 13.sp)
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("Convert to", color = MUTED, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                formats[tab].forEach { f ->
                    FilterChip(selected = fmt == f, onClick = { fmt = f }, label = { Text(f) })
                }
            }

            if (tab == 0 && fmt != "PNG") {
                Spacer(Modifier.height(12.dp))
                Text("Quality: ${quality.toInt()}%", color = MUTED, fontSize = 13.sp)
                Slider(value = quality, onValueChange = { quality = it }, valueRange = 10f..100f)
            }

            Spacer(Modifier.height(18.dp))
            Button(
                onClick = { start() }, enabled = uri != null && !busy,
                modifier = Modifier.fillMaxWidth().height(54.dp),
                colors = ButtonDefaults.buttonColors(containerColor = A),
                shape = RoundedCornerShape(16.dp)
            ) { Text(if (busy) "Converting…" else "Convert", fontSize = 17.sp, fontWeight = FontWeight.Bold) }

            if (busy || progress > 0f) {
                Spacer(Modifier.height(14.dp))
                LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth(), color = B)
            }
            if (status.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Text(status, color = MUTED, fontSize = 14.sp)
            }
        }
    }
}

fun displayName(ctx: Context, u: Uri): String =
    ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
        val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (c.moveToFirst() && i >= 0) c.getString(i) else null
    } ?: "file"

fun saveToDownloads(ctx: Context, fileName: String, mime: String, write: (OutputStream) -> Unit): String {
    val v = ContentValues().apply {
        put(MediaStore.Downloads.DISPLAY_NAME, fileName)
        put(MediaStore.Downloads.MIME_TYPE, mime)
        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ZeroConv")
    }
    val r = ctx.contentResolver
    val out = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: error("Cannot create output file")
    r.openOutputStream(out)!!.use(write)
    return fileName
}

fun convertImage(ctx: Context, u: Uri, base: String, fmt: String, q: Int): String {
    val src = ImageDecoder.createSource(ctx.contentResolver, u)
    val bmp = ImageDecoder.decodeBitmap(src) { d, _, _ -> d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE }
    val webp = if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else legacyWebp()
    val (cf, ext, mime) = when (fmt) {
        "PNG" -> Triple(Bitmap.CompressFormat.PNG, "png", "image/png")
        "JPG" -> Triple(Bitmap.CompressFormat.JPEG, "jpg", "image/jpeg")
        else -> Triple(webp, "webp", "image/webp")
    }
    val b = if (fmt == "JPG") {
        val c = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
        Canvas(c).apply { drawColor(android.graphics.Color.WHITE); drawBitmap(bmp, 0f, 0f, null) }
        c
    } else bmp
    return saveToDownloads(ctx, "$base.$ext", mime) { o -> b.compress(cf, q, o) }
}

@Suppress("DEPRECATION")
fun legacyWebp(): Bitmap.CompressFormat = Bitmap.CompressFormat.WEBP
